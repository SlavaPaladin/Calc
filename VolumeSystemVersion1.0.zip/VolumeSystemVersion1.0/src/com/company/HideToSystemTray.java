package com.company;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.TrayIcon;


public class HideToSystemTray extends JFrame {
    TrayIcon trayIcon;
    SystemTray tray;

    HideToSystemTray() {
        super("Volume System");
        NativeClass nativeClass = new NativeClass();
        System.out.println("creating instance");
        try {
            System.out.println("setting look and feel");
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("Unable to set LookAndFeel");
        }
        if (SystemTray.isSupported()) {
            System.out.println("system tray supported");
            tray = SystemTray.getSystemTray();

            Image image = Toolkit.getDefaultToolkit().getImage("1.png");
            ActionListener exitListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Exiting....");
                    System.exit(0);
                }
            };
            PopupMenu popup = new PopupMenu();
            MenuItem defaultItem = new MenuItem("Open");
            defaultItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    tray.remove(trayIcon);
                    setVisible(true);
                    setExtendedState(JFrame.NORMAL);
                }
            });
            popup.add(defaultItem);
            defaultItem = new MenuItem("Exit");
            defaultItem.addActionListener(exitListener);
            popup.add(defaultItem);
            defaultItem = new MenuItem("Version");
            defaultItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new VersionWindow();
                    System.gc();
                }
            });
            popup.add(defaultItem);


            trayIcon = new TrayIcon(image, Float.toString(nativeClass.getCurrentVolumeLvl() * 100) + "%", popup);

            System.out.println(nativeClass.getCurrentVolumeLvl());

            trayIcon.setImageAutoSize(true);
        } else {
            System.out.println("system tray not supported");
        }
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    tray.add(trayIcon);
                    setVisible(false);
                    System.out.println("added to SystemTray");
                } catch (AWTException exc) {
                }
            }
        });

        addWindowStateListener(new WindowStateListener() {
            public void windowStateChanged(WindowEvent e) {
                if (e.getNewState() == ICONIFIED) {
                    try {
                        tray.add(trayIcon);
                        setVisible(false);
                        System.out.println("added to SystemTray");
                    } catch (AWTException ex) {
                        System.out.println("unable to add to tray");
                    }
                }
                if (e.getNewState() == 7) {
                    try {
                        tray.add(trayIcon);
                        setVisible(false);
                        System.out.println("added to SystemTray");
                    } catch (AWTException ex) {
                        System.out.println("unable to add to system tray");
                    }
                }
                if (e.getNewState() == MAXIMIZED_BOTH) {
                    tray.remove(trayIcon);
                    setVisible(true);
                    System.out.println("Tray icon removed");
                }
                if (e.getNewState() == NORMAL) {
                    tray.remove(trayIcon);
                    setVisible(true);
                    System.out.println("Tray icon removed");
                }
            }
        });
        setIconImage(Toolkit.getDefaultToolkit().getImage("1.png"));
        setResizable(false);
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dimension.width / 2 - this.getSize().width / 2, dimension.height / 2 - this.getSize().height / 2);

        JSlider jSlider = new JSlider(0, 100, Math.round(nativeClass.getCurrentVolumeLvl() * 100));
        jSlider.setOrientation(JSlider.VERTICAL);
        jSlider.setMajorTickSpacing(25);
        jSlider.setMinorTickSpacing(5);
        jSlider.setPaintLabels(true);
        jSlider.setPaintTicks(true);
        jSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                nativeClass.setCurrentVolemeLvl((float) ((JSlider) e.getSource()).getValue());
            }
        });


        Container container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        JButton jButton = new JButton();
        if (nativeClass.getCurrentVolumeLvl() != 0) {
            Icon icon = new ImageIcon("3.png");
            Image image = ((ImageIcon) icon).getImage();
            Image image1 = image.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            Icon icon1 = new ImageIcon(image1);
            jButton.setIcon(icon1);
        } else {
            Icon icon = new ImageIcon("2.png");
            Image image = ((ImageIcon) icon).getImage();
            Image image1 = image.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            Icon icon1 = new ImageIcon(image1);
            jButton.setIcon(icon1);
        }

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (nativeClass.getCurrentVolumeLvl() != 0) {
                    Icon icon = new ImageIcon("2.png");
                    //nativeClass.setMutedStatus(true);
                    nativeClass.setCurrentVolemeLvl(0f);
                    Image image = ((ImageIcon) icon).getImage();
                    Image image1 = image.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                    Icon icon1 = new ImageIcon(image1);
                    jButton.setIcon(icon1);
                } else {
                    // nativeClass.setMutedStatus(false);
                    nativeClass.setCurrentVolemeLvl(0.5f);
                    Icon icon = new ImageIcon("3.png");
                    Image image = ((ImageIcon) icon).getImage();
                    Image image1 = image.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                    Icon icon1 = new ImageIcon(image1);
                    jButton.setIcon(icon1);
                }
            }

        });
        jSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {

                nativeClass.setCurrentVolemeLvl((float) (((JSlider) e.getSource()).getValue()) / 100);
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.isAltDown()) {
                    System.out.println("Key pressed code=" + e.getKeyCode() + ", char=" + e.getKeyChar());

                }
            }
        });/*
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                //if(e.getKeyCode() == KeyEvent.VK_D){
                // nativeClass.setCurrentVolemeLvl(nativeClass.getCurrentVolumeLvl()-0.05f);
                System.out.println("Key pressed code=" + e.getKeyCode() + ", char=" + e.getKeyChar());
                // }
            }
        });*/
        jButton.setPreferredSize(new Dimension(40, 40));
        jButton.setFocusPainted(false);
        jButton.setContentAreaFilled(false);
        jButton.setBorderPainted(false);
        container.add(jSlider);
        container.add(Box.createRigidArea(new Dimension(10, 10)));
        container.add(jButton);
        try {
            tray.add(trayIcon);
            setVisible(false);
        } catch (AWTException ex) {
        }


        setSize(200, 300);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    }

    public TrayIcon getTrayIcon() {
        return trayIcon;
    }

}