package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowStateListener;

public class VersionWindow extends JFrame {

   VersionWindow() {
        super("Version");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }
        setSize(480, 130);
        setIconImage(Toolkit.getDefaultToolkit().getImage("1.png"));
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowStateListener(new WindowStateListener() {
            @Override
            public void windowStateChanged(WindowEvent e) {
                if (e.getNewState() == ICONIFIED) {
                    dispose();
                }
            }
        });
       addWindowFocusListener(new WindowFocusListener() {
           @Override
           public void windowGainedFocus(WindowEvent e) {

           }

           @Override
           public void windowLostFocus(WindowEvent e) {
                    dispose();
           }
       });

        JTextArea jTextArea = new JTextArea();
        jTextArea.setEditable(false);
        jTextArea.setFont(new Font("Times New Roman", Font.PLAIN, 40));
        jTextArea.append("Version System Volume 1.0");
        jTextArea.append("\nCreator Balyk Vyacheslav");
        this.add(jTextArea);
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dimension.width / 2 - this.getSize().width / 2, dimension.height / 2 - this.getSize().height / 2);
        setVisible(true);
    }

}
