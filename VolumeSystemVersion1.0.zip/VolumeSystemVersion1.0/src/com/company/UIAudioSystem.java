package com.company;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.BorderLayout;
import java.util.Dictionary;
import java.util.Hashtable;
import java.net.URL;
import java.awt.*;

public class UIAudioSystem extends JFrame{
    private JLabel label;

    public UIAudioSystem(){
        super("AudioSystemVersion 1.1");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }
    protected static Image createImage(String path, String description) {
        URL imageURL = UIAudioSystem.class.getResource(path);

        if (imageURL == null) {
            System.err.println("Resource not found: " + path);
            return null;
        } else {
            return (new ImageIcon(imageURL, description)).getImage();
        }
    }
}
