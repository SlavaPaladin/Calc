package com.company;



public class NativeClass {
    static{
        System.loadLibrary("qwe");
    }
    public native float getCurrentVolumeLvl();
    public native void setCurrentVolemeLvl(float volumelvl);
    public native void setMutedStatus(boolean mutedstatus);
}
