
/*
 *@author Vyacheslav Balyk
 */

import javax.swing.*;
import java.awt.*;

public class ButtonDesigner extends JButton {



    public ButtonDesigner(String number){
        super(number);
        this.setToolTipText("Click for show random numbers");
        this.setPreferredSize(new Dimension(65,25));
        this.setForeground(Color.white);
        this.setBackground(Color.BLUE);
        this.setFocusPainted(false);

    }

}
