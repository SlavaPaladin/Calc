
/*
 *@author Vyacheslav Balyk
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class IntroFrame extends JFrame {

    private static IntroFrame introFrame;
    private static JFrame sortScreen;
    private static boolean statusSort;
    private static boolean status;
    private static int[] ints;

    public IntroFrame() {
        super("Intro");


        introFrame = this;
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setSize(new Dimension(600, 500));
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dimension.width / 2 - this.getSize().width / 2, dimension.height / 2 - this.getSize().height / 2);

        JButton button = new JButton("Enter");
        button.setToolTipText("Click for show random numbers");
        button.setPreferredSize(new Dimension(65,25));
        button.setForeground(Color.white);
        button.setBackground(Color.BLUE);
        button.setFocusPainted(false);

        JLabel introLabel = new JLabel("How many numbers to display?");
        JTextField introField = new JTextField(4);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createSortScreen(Integer.valueOf(introField.getText()));
                setVisible(false);
            }
        });

        Container container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = 0;

        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.insets = new Insets(7, 0, 0, 0);
        container.add(introLabel, gridBagConstraints);


        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
        container.add(introField, gridBagConstraints);


        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
        container.add(button, gridBagConstraints);

        setVisible(true);
    }

    public static void createSortScreen(int count){

        JFrame frame = new JFrame("SortScreen");
        sortScreen = frame;
        frame.setSize(new Dimension(1000, 500));
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                super.windowClosed(e);
                IntroFrame.showFrame();
            }
        });
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dimension.width / 2 - frame.getSize().width / 2, dimension.height / 2 - frame.getSize().height / 2);

        Container container = new Container();
        GridBagLayout gridBagLayout = new GridBagLayout();
        container.setLayout(gridBagLayout);
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.insets = new Insets(7, 7, 0, 0);

        Random random = new Random();
        ints = generateRandomnumbers(count);
        ints[0] = random.nextInt(31);
        int newcount = count;
        int iteration = 0;
        List<JButton> list = new ArrayList<>();
        for (int i = 0; i < count / 10 + 1; i++) {

            for (int j = 0; j < 10; j++) {
                gridBagConstraints.anchor = GridBagConstraints.WEST;
                gridBagConstraints.gridx = i;
                gridBagConstraints.gridy = j;
                JButton button = new JButton(String.valueOf(ints[iteration++]));
                button.setPreferredSize(new Dimension(65,25));
                button.setForeground(Color.white);
                button.setBackground(Color.BLUE);
                button.setFocusPainted(false);
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int number = Integer.valueOf(button.getText());
                        if (number > 30){
                            JOptionPane.showMessageDialog(null,"Please select a value smaller or equal to 30." );
                        }else{
                            statusSort = false;
                            ints = generateRandomnumbers(count);
                            ints[0] = random.nextInt(31);
                            int g = 0;
                            for (JButton button: list
                            ) {

                                button.setText(String.valueOf(ints[g++]));
                            }
                        }
                    }
                });
                list.add(button);
                container.add(button, gridBagConstraints);
                newcount--;
                if (newcount == 0) {
                    break;
                }

            }

        }
        JButton sort = new JButton("Sort");
        sort.setPreferredSize(new Dimension(65,25));
        sort.setForeground(Color.white);
        sort.setBackground(Color.GREEN);
        sort.setFocusPainted(false);
        sort.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!statusSort) {
                    quickSort(ints, 0, count - 1);
                    status = true;
                    statusSort = true;
                }
                if (status) {
                    int i = 0;
                    for (JButton button : list
                    ) {
                        button.setText(String.valueOf(ints[i++]));
                    }
                    status = false;
                } else {
                    int i = list.size() - 1;
                    for (JButton button : list
                    ) {
                        button.setText(String.valueOf(ints[i--]));
                    }
                    status = true;
                }
            }
        });
        JButton reset = new JButton("Reset");
        reset.setPreferredSize(new Dimension(65,25));
        reset.setForeground(Color.white);
        reset.setBackground(Color.GREEN);
        reset.setFocusPainted(false);

        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeFrame();
            }
        });
        gridBagConstraints.anchor = GridBagConstraints.EAST;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridx = count / 10 + 2;
        container.add(sort, gridBagConstraints);

        gridBagConstraints.gridy = 1;
        container.add(reset, gridBagConstraints);
        frame.getContentPane().add(container, BorderLayout.WEST);
        frame.pack();
        frame.setVisible(true);
    }

    public static void showFrame() {
        introFrame.setVisible(true);
    }
    public static void main(String[] args) {
        new IntroFrame();
    }
    public static int[] generateRandomnumbers(int count) {
        Random random = new Random();
        int[] ints = new int[count];
        for (int i = 0; i < count; i++) {
            ints[i] = random.nextInt(1001);
        }
        return ints;
    }
    public static void quickSort(int[] array, int low, int high) {
        if (array.length == 0)
            return;

        if (low >= high) {
            ints = array;
            return;
        }

        int middle = low + (high - low) / 2;
        int opora = array[middle];


        int i = low, j = high;
        while (i <= j) {
            while (array[i] < opora) {
                i++;
            }

            while (array[j] > opora) {
                j--;
            }

            if (i <= j) {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                i++;
                j--;
            }
        }


        if (low < j)
            quickSort(array, low, j);

        if (high > i)
            quickSort(array, i, high);
    }
    public static void closeFrame() {
        sortScreen.dispose();
        IntroFrame.showFrame();
        statusSort = false;
    }
}

