
/*
 *@author Vyacheslav Balyk
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IntroFrame extends JFrame {

    private static IntroFrame introFrame;

    public IntroFrame() {
        super("Intro");
        introFrame = this;
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setSize(new Dimension(600, 500));
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dimension.width / 2 - this.getSize().width / 2, dimension.height / 2 - this.getSize().height / 2);

        ButtonDesigner introButton = new ButtonDesigner("Enter");
        JLabel introLabel = new JLabel("How many numbers to display?");
        JTextField introField = new JTextField(4);

        introButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SortScreen(Integer.valueOf(introField.getText()));
                setVisible(false);
            }
        });


        Container container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
//        gridBagConstraints.weightx = 0;
//        gridBagConstraints.weighty = 0;
          gridBagConstraints.gridy = 0;
//        gridBagConstraints.gridheight = 0;
//        gridBagConstraints.gridwidth = 0;


        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.insets = new Insets(7, 0, 0, 0);
        container.add(introLabel, gridBagConstraints);


        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
        container.add(introField, gridBagConstraints);


        gridBagConstraints.fill = GridBagConstraints.VERTICAL;
        gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
        container.add(introButton, gridBagConstraints);


        setVisible(true);
    }

    public static void showFrame() {
        introFrame.setVisible(true);
    }
}
